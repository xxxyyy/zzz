/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fxtg;

import java.rmi.RemoteException;

/**
 *
 * @author xiaodai
 */
public class Fxtg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws RemoteException {
        // TODO code application logic here
       
    }
}
