package fxtg;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Enumeration;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingException;

/**
 * fxtgClient类封装了客户端的行为，GUI应该调用这个类以与服务器进行交互，包括登陆、信息查询和操作等。
 * 类中大部分的方法都可能抛出RemoteException，因为它们大多都是调用远程方法的，这使得可能出现的异常比较复杂。
 *
 * @author xiaodai
 * @version 0.01
 */
public class fxtgClient {

    fxtgServer nowServer;
   
    public static void main(String args[]) throws NamingException, RemoteException
    {
        fxtgClient tmpClient = new fxtgClient();
        tmpClient.login("test01", "123456");
        System.out.println(tmpClient.getUserID());
    }
    
    /**
     * 初始化，包括从RMI注册表得到远程存根。极有可能抛出Remote和Naming异常。 因为与server的连接在这里建立，如果出错就直接抛出来了。
     * 访问远程目标总是不太靠谱的，这个构造函数很不稳定，应该改进。 比如建立失败容忍阈值多次尝试等等。
     *
     * @throws NamingException
     * @throws RemoteException
     */
    public fxtgClient() throws NamingException, RemoteException {
        //通过RMI注册表获得远程fork存根。
        Context namingContext;
        namingContext = new InitialContext();
        Enumeration<NameClassPair> e = namingContext.list("rmi://localhost/");
        while (e.hasMoreElements())
        {
            System.out.println(e.nextElement().getName());
        }
        String url = "rmi://localhost/fxtg_Fork";
        fxtgFork nowFork;
        nowFork = (fxtgFork) namingContext.lookup(url);
        //用fork获得server存根
        nowServer = nowFork.getAServer();
        nowServer.logout();//重置登陆状态以免不测
    }

    /**
     * 用来检查当前对象的登陆状态(若检查成功，检查行为会刷新用户登陆的AFK时间)。
     *
     * @return true当前登陆状态有效（远程与本地的登陆状态统一），false则表示无效。
     * 若返回false，说明当前的登陆状态已经于远程不统一，应该logout以确保健壮性。
     * @throws RemoteException
     */
    public boolean checkLog() throws RemoteException {
        return nowServer.checkLog() != 0L;
    }

    /**
     * 通过用户名和密码向server认证身份，使用前应尽量确认当前处于guest状态。 当前仅能处理成功登陆和者用户名不存在或密码错误两种确定错误。
     * 其他的返回-1，比如已经登陆，不管重复的login动作是否是已经登陆的账号以及是否合法。
     * 当前用户名密码均已明码表示、传递和保存，以后应该用MD5等方法来确保安全性。
     *
     * @param UserName 用户名
     * @param Password 密码
     * @return 0表示正常登陆，1表示用户名不存在或者密码错误，-1未定义错误（能返回-1表示这个错误发生的比较安全）。
     * @exception RemoteException
     */
    public int login(String UserName, String Password) throws RemoteException {
        return nowServer.login(UserName, Password);
    }

    /**
     * 用来重置登陆状态。 当远程调用出现奇葩问题的时候可能导致远程和本地的登陆状态不统一造成混乱。
     *
     * @return 0表示登陆状态已经被重置，不论原来是否已经登陆。-1未定义错误。
     * @exception RemoteException
     */
    public int logout() throws RemoteException {
        return nowServer.logout();
    }

    /**
     * 获得登陆账号的ID。
     *
     * @return 当前登陆账号的ID，注意为64位整型。Guset为0。
     * @throws RemoteException
     */
    public Long getUserID() throws RemoteException {
        return nowServer.checkLog();
    }

    /**
     * 获得登陆账号的用户名。
     *
     * @return 当前登陆账号的用户名，若未登陆则为返回“Guset”（用户名至少6个字符，不会冲突）。
     * @throws RemoteException
     */
    public String getUserName() throws RemoteException {
        String tmpName = nowServer.getUserName();
        if (tmpName == null) {
            return "Guest";
        } else {
            return tmpName;
        }
    }

    /**
     * 得到登陆用户的类型
     *
     * @return 0表示Guest，1表示买家，2表示卖家。
     * @throws RemoteException
     */
    public int getUserType() throws RemoteException {
        int tmpType = nowServer.getUserType();
        if (tmpType == -1) {
            nowServer.logout();
            return 0;
        }
        return tmpType;
    }

    /**
     * 由关键字、状态限定掩码、类别向量及用户ID向服务器搜索符合条件的订单记录信息。
     *
     * @param KeyString 搜索的关键字，目前支持的比较简单（%str%）。 <em>若无限制应该传空串而不是null。</em>
     * @param stateMask
     * 搜索的订单的状态限定，1表示已经成功结束，2表示等待买家，4表示等待卖家，8表示买家不足团购被中止，16表示没有卖家出价而被中止（这个规则是二进制的掩码形式）。
     * <em>Server会检查这个请求是否合法，并不是所有的请求都会得到回应。调用者应该尽量使得它合法，以减少麻烦。</em>
     * 以掩码的形式传递需要的订单状态应该是够的，它有足够的可扩充性。
     * @param typeVector Long型的向量，传递一个物品类型的父子链，这个是与淘宝API挂钩的。
     * @param userID
     * 如果需要返回与某ID用户有关的记录（这个应该用于类似于“我参加的团购”（对于买家）、“我出价的团购”(对于卖家)等等）。
     * 合理使用状态掩码可以得到丰富的结果。<em>这个功能目前只支持请求自己的ID，因为现在账户系统尚不支持权限这么高级的东西。</em>
     * <em>如果不限定，则传入0（使用者应该分清楚0与Guest的差别，以免在Guest时调用了与语义不符合的数据）</em>
     * @return 返回fxtgRecord的向量，为搜索的结果。 返回的结果可能是一个空的Vector或者null，两者的含义有区别。
     * 若为空向量则表示没有搜索到结果或者发生了比较安全的错误(比如给定的类别父子链不合法，返回空结果符合逻辑)，返回null则表示错误可能更严重而以至于不能返回一个“空结果”（很可能是请求越权）。
     * @throws RemoteException
     */
    public ArrayList<fxtgRecord> getRecord(String KeyString, int stateMask, ArrayList<Long> typeVector, Long userID) throws RemoteException {
        return nowServer.getRecord(KeyString, stateMask, typeVector, userID);
    }

    /**
     * 请求一个订单该用户作为买家的出价信息向量
     *
     * @param OrderID 订单ID，这个值应当由返回的fxtgRecord中的OrderID获得。
     * @return 调用者应该确保这个查询时合法的（1、是买家；2、该ID的订单出过价；3、其他合法限制）。
     * 调用者保证调用合法并不困难，因此对于不合法的请求Server会返回不可控的结果。
     * 将会返回一个向量，包含买家多次提出购买请求（如果有的话，server支持同个买家以多种价格和数量来购买）。
     * <em>返回的向量的元素顺序无任何意义。</em>
     * @throws RemoteException
     */
    public ArrayList<fxtgPriceAndAmount> getMyBuyPrice(Long OrderID) throws RemoteException {
        return nowServer.getMyBuyPrice(OrderID);
    }

    /**
     * 请求一个订单该用户作为卖家的出价信息
     *
     * @param OrderID 请求出价的订单ID，返回价格和该价格下的买家数量（不是人数，是物品数量）。
     * @return 同样，不合法的请求结果不可控（大多返回null），请调用者自己保证。
     * @throws RemoteException
     */
    public fxtgPriceAndAmount getMySellPrice(Long OrderID) throws RemoteException {
        return nowServer.getMySellPrice(OrderID);
    }

    /**
     * 卖家由订单号和出价得到买家数量。 此价格可以满足多少买家的出价，这个数量是商品数量，因为单个买家的购买数量可以是多个的。
     * <em>这是一个询问请求，不是正式出价。</em>因此Server对这个请求的安全判定比较弱。
     * 因此GUI不需要卖家登陆既可以使用该方法得到一个商品的买家购买数量-价格的分布（比如用于图形化，我认为这样直观友好）。
     * <em>以现有的数据库设计，这个操作消耗很大，请适度请求。</em>
     * 原则上，调用者应该尽量调用处于等待卖家的订单，不保证处于其他状态的请求返回的结果。
     * （比如在等待买家的阶段数据是动态的，维护这个将非常消耗且麻烦，而且我觉得意义不大）
     *
     * @param OrderID 请求订单ID。
     * @param price 请求的出价。
     * @return 满足出价的购买数。返回-1则表示请求被拒绝。
     * @throws RemoteException
     */
    public int askBuyerAmount(Long OrderID, double price) throws RemoteException {
        return nowServer.askBuyerAmount(OrderID, price);
    }

    /**
     * 卖家向OrderID订单出价。 这是卖家正式报价的方法。
     *
     * @param OrderID 订单ID。
     * @param price 出价。
     * @return 调用者应该确保请求是合法的（1、有效的卖家登陆；2、订单处于等待卖家状态；3、其他合法约束）。
     * <em>与买家不同，卖家只能对一个订单报一个价格。如果要重新报价，需要先取消他的卖家报价。否则会插入异常。</em>
     * 返回-1则表明这个请求被拒绝了，0则表示成功。
     * @throws RemoteException
     */
    public int offerSellPrice(Long OrderID, double price) throws RemoteException {
        return nowServer.offerSellPrice(OrderID, price);
    }

    /**
     * 买家提供给一个商品的ID，发起一个团购请求。
     * <em>该商品应该无正在进行的订单，Server规定同一商品同时只能有一个团购，这在逻辑上是说得通的。</em>
     *
     * @param ItemID 发起团购的物品的淘宝ID
     * @param timeWaitBuyer 等待买家时间段长度
     * @param timeWaitSeller 等待买家时间段长度
     * @return 返回建立的团购的ID。<em>调用者应当妥善保管这个结果。</em>
     * 对订单的操作需要有OrderID，而若没有妥善保管这个ID。若对订单无购买操作则不会通过searchRecord得到。
     * 若-1则表示请求被拒绝了，0则表示成功。 目前server对拒绝请求的原因并不准备提供更详尽的原因，若以后有精力可以完善。
     * <em>对于两个时间段，为了server健壮性，会有极大极小的限制。（保证24-72小时是一定有效的，但server可能修改这个设定）若时间段不合法则返回-1。</em>
     * @throws RemoteException
     */
    public Long createOrder(Long ItemID, int timeWaitBuyer, int timeWaitSeller) throws RemoteException {
        return nowServer.createOrder(ItemID, timeWaitBuyer, timeWaitSeller);
    }

    /**
     * 买家由订单ID向该订单提出购买意向。 调用者应当保证该订单处于等待买家的状态。
     *
     * @param OrderID 订单ID
     * @param price 单价
     * @param amount 数量（目前认为商品的数量为离散的）
     * @return 0表示出价成功，-1表示被拒绝。
     * @throws RemoteException
     */
    public int offerBuyPriceAndAmount(Long OrderID, double price, int amount) throws RemoteException {
        return nowServer.offerBuyPriceAndAmount(OrderID, price, amount);
    }

    /**
     * 取消一个购买动作 <em>只有处于等待买家状态时可以取消，若订单已经过渡到等待卖家阶段，则不可反悔。</em>
     *
     * @param BuyID 要取消的购买动作的ID。
     * @return 若server拒绝请求，则返回-1。成功则返回0。
     * @throws RemoteException
     */
    public int cancelBuy(Long BuyID) throws RemoteException {
        return nowServer.cancelBuy(BuyID);
    }

    /**
     * 取消一个出售动作。 若卖家要重新报价，则必须先使用这个方法。以免重复报价造成插入异常。
     *
     * @param SellID 出售动作的ID。
     * @return -1拒绝，0成功。
     * @throws RemoteException
     */
    public int cancelSell(Long SellID) throws RemoteException {
        return nowServer.cancelSell(SellID);
    }

    /**
     * 用来注册新账号的方法。
     *
     * @param userName
     * 用户名<em>应该是不少于6个字符，不超过20个字符，以英文开头的英文和数字混合的字符串（不区分大小写）。</em>
     * @param password 密码<em>应该是6-10位的纯数字，尚不支持忘记密码找回。</em>
     * @param type 注册用户的类别。
     * @return 0表示新建成功，-1表示被拒绝。
     * @throws RemoteException
     */
    public int register(String userName, String password, int type) throws RemoteException {
        return nowServer.register(userName, password, type);
    }
}
