package fxtg;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author xiaodai
 */
public interface fxtgFork extends Remote {

    public fxtgServerImpl getAServer() throws RemoteException;
}
