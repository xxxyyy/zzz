package fxtg;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * 此类将注册到RMI注册表中，远程client通过注册表得到该类的对象的存根，用于开启独立的server。
 *
 * @author xiaodai
 */
public class fxtgForkImpl extends UnicastRemoteObject implements fxtgFork {

    public fxtgForkImpl() throws RemoteException {
    }

    public fxtgServerImpl getAServer() throws RemoteException {
        return new fxtgServerImpl();
    }
}
