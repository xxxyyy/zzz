/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fxtg;

import java.rmi.RemoteException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * 服务器主线程，运行着唯一的Fork实例，给每个Client分配Server对象。
 * @author xiaodai
 */
public class fxtgServerThread {

    public static void main(String[] args) throws RemoteException, NamingException {
        System.out.println("Constructing server implementation...");
        fxtgForkImpl mainFork = new fxtgForkImpl();

        System.out.println("Binding server implementation to registry...");
        Context namingContext = new InitialContext();
        namingContext.bind("rmi:fxtg_Fork", mainFork);

        System.out.println("Waiting for invocations from clients...");

    }
}
